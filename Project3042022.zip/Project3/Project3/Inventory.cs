﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class Inventory
    {
        public List<Item> PlayerInventory = new List<Item>()
        {


        };
    }
}
