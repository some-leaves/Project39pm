﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
   
    public class Entity
    {
        public string Name { get; set; }
        public string Species { get; set; }
        public Entity(string name, string species)
        {
            Name = name;
            Species = species;
        }

       public Entity()
       {

       }
        
    }
}
