﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{

    public class Item
    {
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public float ItemPrice { get; set; }

        public Item(string itemname, string itemdescription, float itemprice)
        {
            ItemName = itemname;
            ItemDescription = itemdescription;
            ItemPrice = itemprice;
           
        }

        //items to be used throughout the game
        Item CornKernels = new Item("Corn Kernerls", " Kernels are for growing corn!", 2.65f);
        Item CornStalks = new Item("Corn stalk", "Corn stalks are good for selling, ", 200);
        Item Repellent = new Item("Bat Repellent","Have to many bats? Use the lure to knock down your bat population by 5%", 3.00f);
        Item Pesticide = new Item("Pesticide"," Have to many beetles? Use this to knock down your beetle population", 5.00f);
        Item Lure = new Item("Bat Lure","Need more bats? Use this lure to attract bats to your ecosystem", 10.00f );
        

    }
}
