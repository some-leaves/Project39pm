﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    //add the items here 
    public class Store
    {
        //assist with data binding for this class
       
        public Item CornKernels = new Item("Corn Kernerls", " Kernels are for growing corn!", 2.65f);
        public Item CornStalks = new Item("Corn stalk", "Corn stalks are good for selling, ", 20);
        public Item Repellent = new Item("Bat Repellent", "Have to many bats? Use the lure to knock down your bat population by 5%", 3.00f);
        public Item Pesticide = new Item("Pesticide", " Have to many beetles? Use this to knock down your beetle population", 5.00f);
        public Item Lure = new Item("Bat Lure", "Need more bats? Use this lure to attract bats to your ecosystem", 10.00f);

        //how to put the items into a list and show them to the player. 

        // have to make buttons for the Add to Order 

        //




    }
}
