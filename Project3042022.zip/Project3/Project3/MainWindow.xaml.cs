﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Project3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public static string LoadTextFromFile(string path) => File.ReadAllText(path);
        public MainWindow()
        {
            InitializeComponent();
        }
       
        private void Inventory_Click(object sender, RoutedEventArgs e)
        {
            TBOutput.Text = "Here is your Inventory :";
          

        }

        private void Store_Click(object sender, RoutedEventArgs e)
        {
            Store store = new Store();

        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void CreditsBTN_Click(object sender, RoutedEventArgs e)
        {
            TBOutput.Text = "Created By: Kaveonna Gamble, ";
        }
    }
}
