﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Project3
{
    public class ExternalData
    {
        public static string LoadTextFromFile(string path) => File.ReadAllText(path);

        public static List<Item> LoadLinesFromFile(string path)
        {
            //temp list of items
            List<Item> items = new List<Item>();

            foreach (string s in File.ReadAllLines(path)) //Read all line returns string array
            {
              //  items.Add(new Item() { Name = s }); //make a new instance of an item
            }

            return items;
        }

    }
}
