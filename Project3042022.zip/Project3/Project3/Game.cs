﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class Game
    {
        // Data binding for this class
        // event handlers for when Beetles are getting low & for when bats are getting low & when 
        // set up a warning text block 
        //create a system for the Beetle eating the corn and the bats eating the beetles
        Store store = new Store();
        Player player = new Player();
        BrackenCave Cave = new BrackenCave();

        public enum Days
        {
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday,
        }
        public enum Weather
        {
            Rain,
            Storm,
            Sleet,
            Tornado,
            Warm,
            Clear,
            Cloudy,
            Snow,


        }

        

        

    }
}
