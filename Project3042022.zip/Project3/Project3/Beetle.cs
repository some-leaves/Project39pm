﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class Beetle : Entity
    {
        public Beetle()
        {
            Name = "Guano Beetle";
            Species = "Jacobsoniidae";
        }
    }
}
