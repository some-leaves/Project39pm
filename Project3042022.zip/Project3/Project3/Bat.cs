﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project3
{
    public class Bat : Entity
    {
        public Bat()
        {
            Name = "Bat";
            Species = "Brazilian free-tailed bats or Tadarida brasiliensis";
        }
    }
}
